﻿namespace MessageBroker.Controllers
{
    public class Message
    {
        public string ProducerName { get; set; }
        public string Content { get; set; }
    }
}
