﻿namespace ConsumerLibrary
{
    public class Class1
    {

    }
}
